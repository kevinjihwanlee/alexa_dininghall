# alexa_dininghall

# TO DO
* being able to choose dining hall (currently set to Sargent)